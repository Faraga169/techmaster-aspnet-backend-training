﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingCenter.DAL.Persistent.Models
{
    public enum EnrollmentStatus
    {

        Pending = 1,
        Active = 2,
        Completed = 3,
        Cancelled=4
    }
}
